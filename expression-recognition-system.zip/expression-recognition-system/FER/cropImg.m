function [ cropped_img ] = cropImg( img, centers )

    % crop using heuristics
    rotated_right = centers(1, :);
    rotated_left = centers(2, :);

    eye_distance = sqrt((rotated_right(1)-rotated_left(1))^2 + (rotated_right(2)-rotated_left(2))^2);

    % find top left corner of image
    % width is roughly 2x the eye distance
    crop_x = mean([rotated_right(1) rotated_left(1)]) - eye_distance;
    % height is roughly 3x the eye distance
    crop_y = rotated_left(2) - eye_distance;

    crop_rect = [crop_x crop_y 2.0*eye_distance 3.0*eye_distance];
    cropped_img = imcrop(img, crop_rect);
end

