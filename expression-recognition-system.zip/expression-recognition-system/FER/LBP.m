function [ H ] = LBP( img, P, R, num2histbin )
    
    % pad image with border of zeros
    img_filled = zeros(size(img) + 2*R);
    img_filled(R+1:end-R, R+1:end-R) = img;

    [M, N] = size(img_filled);
    
    [X, Y] = meshgrid(R+1:N-R, R+1:M-R);
    
    th = linspace(0, 2*pi, P+1) + pi + pi/4;
    th = th(1:end-1);
    
    X_linear = X(:);
    Y_linear = Y(:);
    x_cos = repmat(R * cos(th), size(X_linear, 1), 1);
    y_sin = repmat(R * sin(th), size(Y_linear, 1), 1);
    xunit = bsxfun(@plus, x_cos, X_linear);
    yunit = bsxfun(@plus, y_sin, Y_linear);
    
    pixels=interp2(img_filled, xunit, yunit, 'linear');
    threshold_values = img(:);
    binary = bsxfun(@ge, pixels, threshold_values);
    
    decimal = bi2de(binary);
    
    % apply decimal number to bin mapping
    bins_mapped = num2histbin(decimal + 1);
    H = histcounts(bins_mapped, 0.5:length(unique(num2histbin))+1);

end
 

 
