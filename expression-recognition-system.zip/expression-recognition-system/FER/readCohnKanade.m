function [ images, labels ] = readCohnKanade()
% Reads images and emotion labels from Cohn Kanade Database
% assumes that Emotion and cohn-kanade-images folder are in the same
% directory as the calling script
%
% Output:
%   images - cell array of images
%   labels - vector of emotion labels

    ROOT_DIR = 'Emotion';
    NUM_PEAK_INSTANCE = 3;

    samples = dir(ROOT_DIR);
    samples = samples(arrayfun(@(x) x.name(1), samples) ~= '.');

    labels = [];
    images = {};
    index = 1;

    for i=1:length(samples)
        sample = samples(i).name;
        sample_dir = strcat(ROOT_DIR, '/', sample);
        subsamples = dir(sample_dir);
        subsamples = subsamples(arrayfun(@(x) x.name(1), subsamples) ~= '.');

        for j=1:length(subsamples)
            subsample = subsamples(j).name;
            subsample_dir = strcat(sample_dir, '/', subsample);
            instances = dir(subsample_dir);
            instances = instances(arrayfun(@(x) x.name(1), instances) ~= '.');

            for k=1:length(instances)
                instance = instances(k).name;
                instance_dir = strcat(subsample_dir, '/', instance);

                % read label from text file
                fd = fopen(instance_dir, 'r');
                label = fscanf(fd, '%d');

                fclose(fd);

                % grab the corresponding image
                img_file = strrep(instance, '_emotion.txt', '');

                % grab peak images and neutral
                split = strsplit(img_file, '_');
                peak_max = str2double(split(length(split)));
                base_img_dir = strcat('cohn-kanade-images/', sample, ...
                    '/', subsample, '/');

                for peak_offset=0:NUM_PEAK_INSTANCE-1
                    num_str = sprintf('%3.8d', peak_max - peak_offset);
                    split{length(split)} = num_str;
                    img_dir = strcat(base_img_dir, ...
                        strjoin(split, '_'), '.png');
                    img = imread(img_dir);

                    % convert to grayscale if necessar]y
                    if size(img, 3) > 1
                        img = rgb2gray(img);
                    end

                    images{index} = img;
                    index = index + 1;
                    labels = [labels label+1];
                end

                % add neutral image
                if peak_max > 1
                    num_str = sprintf('%3.8d', 1);
                    split{length(split)} = num_str;
                    img_dir = strcat(base_img_dir, ...
                        strjoin(split, '_'), '.png');
                    img = imread(img_dir);

                    % convert to grayscale if necessary
                    if size(img, 3) > 1
                        img = rgb2gray(img);
                    end

                    images{index} = img;
                    index = index + 1;
                    labels = [labels 1];
                end
            end
        end
    end

end

