function [ lookup ] = createBinLookupTable( P )
    index = 2;
    lookup = zeros(2^P, 1);
    for i=0:(2^P - 1)
        binary_vec = de2bi(i, P, 'left-msb');
        % add first bit to the end so we consider the binary representation
        % as circular when computing uniformity
        circular_binary = [binary_vec binary_vec(1)];
        uniform = sum(abs(diff(circular_binary))) <= 2;
        if uniform
            lookup(i+1) = index;
            index = index + 1;
        else
            lookup(i+1) = 1;
        end
    end
end

