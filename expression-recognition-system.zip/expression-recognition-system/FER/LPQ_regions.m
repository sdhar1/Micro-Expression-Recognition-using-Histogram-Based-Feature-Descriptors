function [ H ] = LPQ_regions( sequence, region_n, region_m, winSize,decorr,freqestim, mode)
    fun = @(block_struct) single_region_LPQ(block_struct, winSize, decorr, freqestim, mode);
    H = blockproc(sequence, [region_n region_m], fun, 'PadPartialBlocks', true, 'TrimBorder', false);

    H = reshape(H', 1, []);
end

function [ H ] = single_region_LPQ(block_struct, winSize, decorr, freqestim, mode)

    img_block = block_struct.data;

    H = lpq(img_block, winSize, decorr, freqestim, mode);
end

