function [ rotated_img, eye_center ] = rotateImg( img, EyeDetect )
    % detect the eyes
    BB = step(EyeDetect, img);

    % if we did not detect two eyes, skip this image
    if size(BB, 1) < 2
        rotated_img = NaN;
        eye_center = NaN;
        return;
    end

    % find the center of left and right eyes
    X = BB(:, 1) + BB(:, 3)./2;
    Y = BB(:, 2) + BB(:, 4)./2;
    center = [X Y];

    [~, min_index] = min(X(:, 1));
    BB_left = center(min_index, :);
    [~, max_index] = max(X(:, 1));
    BB_right = center(max_index, :);

    if BB_left == BB_right
        [~, min_index] = min(Y(:, 1));
        BB_left = center(min_index, :);
        [~, max_index] = max(Y(:, 1));
        BB_right = center(max_index, :);
    end

    % rotate the image
    angle = atand((BB_right(1, 2)-BB_left(1, 2))/(BB_right(1, 1)-BB_left(1, 1)));
    rotated_img = imrotate(img, angle, 'crop');

    % rotate center points
    rot = [cosd(-angle) -sind(-angle); sind(-angle) cosd(-angle)];
    img_center = [size(img, 1)/2 size(img, 2)/2];

    rotated_right = rot * (BB_right-img_center)';
    rotated_right = rotated_right' + img_center;
    rotated_left = rot * (BB_left-img_center)';
    rotated_left = rotated_left' + img_center;

    eye_center = [rotated_right; rotated_left];
end

