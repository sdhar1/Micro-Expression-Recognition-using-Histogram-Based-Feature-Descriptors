load images_processed_55.mat

tic
P = 8;
R = 2;
regions_n = 16;
regions_m = 12;
% create lookup table for number to histogram bin
% if the binary representation is uniform then it will always map to
% the first bin
num2histbin = createBinLookupTable(P);

[rows_img, cols_img] = size(images{1});
bins = P * (P - 1) + 3;
total_bins = bins * ceil(rows_img/regions_n) * ceil(cols_img/regions_m);
features = zeros(length(images), total_bins);

skipped = [];
for i=1:length(images)
    img = images{i};

    feat_vec = LBP_regions(img, P, R, num2histbin, regions_n, regions_m);
    if length(feat_vec) ~= total_bins
        skipped = [skipped i];
    else
        features(i, :) = feat_vec;
    end
end

% clear skipped images...something went wrong in preprocessing
features(skipped, :) = [];
labels(:, skipped) = [];

save('images_lbp_regions_8_2.mat', 'features', 'labels');
toc