
% read images from database
tic
[images_raw, labels_raw] = readCohnKanade();

% detect eyes, normalize face, crop face
images = {};
labels = [];
index = 1;
EyeDetect = vision.CascadeObjectDetector('RightEyeCART');
EYE_DIST = 55.0; % taken from paper
disp(['Total images: ' num2str(length(images_raw))]);
for i=1:length(images_raw)
    img = images_raw{i};

    center = detectEyes(img, EyeDetect);

    % if we couldnt find the eyes, ask user to pick, right then left
    if isnan(center)
        try
            disp(['Picking eyes for image : ' num2str(i) '/' num2str(length(images_raw))]);
            imshow(img);
            [x, y] = ginput(2);
            center = [x y];
            close;
        catch
            disp(['Sequence ' num2str(i) ' could not be rotated']);
            continue;
        end
    end

    [img_rotated, rotated_center] = rotateImg(img, center);
    [normalized_img, normalized_center] = normalizeImg(img_rotated, rotated_center, EYE_DIST);
    cropped_img = cropImg(normalized_img, normalized_center);

    images{index} = cropped_img;
    labels(index) = labels_raw(i);
    index = index + 1;
end

toc

save('images_processed_55.mat', 'images', 'labels');