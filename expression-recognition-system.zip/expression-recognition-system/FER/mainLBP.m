load 'images_lbp_regions_8_2.mat'
tic
template = templateSVM('Standardize', 1);

model = fitcecoc(features, labels, 'Learners', template, 'CrossVal', 'on', 'Coding', 'onevsall');

100 * (1 - kfoldLoss(model))
toc




