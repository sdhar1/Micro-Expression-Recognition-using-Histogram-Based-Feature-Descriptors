function [ H ] = LBP_regions( img, P, R, num2histbin, region_n, region_m )
    
    th = linspace(0, 2*pi, P+1) + pi + pi/4;
    th = th(1:end-1);
    fun = @(block_struct) single_region_LBP(block_struct, R, th, num2histbin);
    H = blockproc(img, [region_n region_m], fun, 'PadPartialBlocks', true, 'TrimBorder', false);
    
    % stack all rows into one long vector
    H = reshape(H', 1, []);
end

function [H_single] = single_region_LBP(block_struct, R, thetas, num2histbin)
    % assume that vertical and horizontal padding is equal
    img_block = block_struct.data;
    M = block_struct.blockSize(1);
    N = block_struct.blockSize(2);
    
    % pad image with border of zeros
    img_block_filled = zeros(size(img_block) + 2*R);
    img_block_filled(R+1:end-R, R+1:end-R) = img_block;
    
    [X, Y] = meshgrid(1+R:M+R, 1+R:N+R);
    
    X_linear = X(:);
    Y_linear = Y(:);
    x_cos = repmat(R * cos(thetas), size(X_linear, 1), 1);
    y_sin = repmat(R * sin(thetas), size(Y_linear, 1), 1);
    xunit = bsxfun(@plus, x_cos, X_linear);
    yunit = bsxfun(@plus, y_sin, Y_linear);
    
    pixels=interp2(img_block_filled, xunit, yunit, 'linear');
    threshold_values = img_block(:);
    binary = bsxfun(@ge, pixels, threshold_values);
    
    decimal = bi2de(binary);
    
    % apply decimal number to bin mapping
    bins_mapped = num2histbin(decimal + 1);
    H_single = histcounts(bins_mapped, 0.5:length(unique(num2histbin))+1);

end
 