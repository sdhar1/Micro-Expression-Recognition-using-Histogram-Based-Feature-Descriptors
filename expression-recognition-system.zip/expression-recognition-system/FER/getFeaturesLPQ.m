load images_processed_55.mat;

regions_n = 35;
regions_m = 25;
%parameter description
winSize = 3;
decorr = 1;
freqestim = 1;
mode = 'nh';
features = [];

sz = size(images{1});
tic
for i=1:length(images)
    img = images{i};
    img = imresize(img, sz);
    feat_vec = lpq_regions(img, regions_n, regions_m, winSize, decorr, freqestim, mode);
    features = [features; feat_vec];
end

save('images_lpq_CK.mat', 'features', 'labels');
toc