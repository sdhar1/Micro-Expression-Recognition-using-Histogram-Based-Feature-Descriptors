function [ H ] = LPQ_regions( sequence, region_n, region_m, weight_vector,decorr,winSizes)
    fun = @(block_struct) single_region_LPQ_TOP(block_struct, weight_vector, decorr, winSizes);
    H = blockproc(sequence, [region_n region_m], fun, 'PadPartialBlocks', true, 'TrimBorder', false);

    H = reshape(H', 1, []);
end

function [ H ] = single_region_LPQ_TOP(block_struct, weight_vector, decorr, winSizes)
    
    img_block = block_struct.data;
    
    H = LPQ_TOP(img_block, weight_vector, decorr, winSizes);
end

