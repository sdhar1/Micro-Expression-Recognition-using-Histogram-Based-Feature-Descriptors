function [vid_seq, labels] = readCasme2(ROOT)
% Reads images and emotion labels from CASME II Database
% Output:
%   images - cell array of images
%   labels - vector of emotion labels
    
    ROOT_DIR = strcat('casme2-dataset/', ROOT);
    META_FILE = 'casme2-dataset/CASME2-coding-20140508.xlsx';
    
    subjects = dir(ROOT_DIR);
    subjects = subjects(arrayfun(@(x) x.name(1), subjects) ~= '.');
    
    [~, seq_names] = xlsread(META_FILE, 'B2:B256');
    [~, label_names] = xlsread(META_FILE, 'I2:I256');
    
    labels = {};
    
    vid_seq = {};
    seq_index = 1;

    for i=1:length(subjects)
        subject = subjects(i).name;
        subject_dir = strcat(ROOT_DIR, '/', subject);
        sequences = dir(subject_dir);
        sequences = sequences(arrayfun(@(x) x.name(1), sequences) ~= '.');

        for j=1:length(sequences)
            sequence = sequences(j).name;
            
            label_index = find(strcmp(sequence, seq_names));
            label = label_names{label_index};
            
            % skip fear and sadness
            if strcmp(label, 'fear') || strcmp(label, 'sadness')
                continue;
            end
            
            labels{seq_index} = label;

            sequence_dir = strcat(subject_dir, '/', sequence);
            frames = dir(sequence_dir);
            frames = frames(arrayfun(@(x) x.name(1), frames) ~= '.');
            
            vid_seq{seq_index} = {};
            frame_index = 1;
            
            for k=1:length(frames)
                frame = frames(k).name;
                frame_dir = strcat(sequence_dir, '/', frame);

                img = imread(frame_dir);
                vid_seq{seq_index}{frame_index} = img;
                frame_index = frame_index + 1;
            end
            seq_index = seq_index + 1;
        end
    end


end