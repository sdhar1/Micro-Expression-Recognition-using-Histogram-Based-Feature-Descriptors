[seq, labels] = readCasme2('Cropped');

%features matrix
features = zeros(length(seq), 9216);

%setting up argument variables for LBP-TOP
weight_vector=[0.5 1 1];
decorr = [0.1 0.1];
winSizes = [5 5 3];

tic
for i = 1:length(seq)
    tic
    expframes = [];
    for img = 1:length(seq{i})
        frame = rgb2gray(seq{i}{img});
        frame = imresize(frame, [280 230]);
        expframes = cat(3,expframes,frame);
    end
    feature_vector = LPQ_regions(expframes, 80, 80, weight_vector, decorr, winSizes);
    features(i, :) = feature_vector;
    toc
end

save('microexp_lpq_top_cropped.mat', 'features', 'labels');
toc
