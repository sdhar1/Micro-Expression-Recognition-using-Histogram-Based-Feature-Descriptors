[seq, labels] = readCasme2('Cropped');
features = [];

P = 8;
R = [2 2 4];
regions_n = 35;
regions_m = 29;
% create lookup table for number to histogram bin
% if the binary representation is uniform then it will always map to
% the first bin
num2histbin = createBinLookupTable(P);

for i = 1:length(seq)
    tic
    expframes = [];
    for img = 1:length(seq{i})
        frame = im2double(rgb2gray(seq{i}{img}));
        frame = imresize(frame, [280 230]);

        expframes = cat(3,expframes,frame);
    end
    feature_vector = lbp_top_regions(expframes, P, R, num2histbin, regions_n, regions_m, 1);
    features(i, :) = feature_vector;
    toc
end

save('microexp_lbp_top_cropped.mat', 'features', 'labels');
