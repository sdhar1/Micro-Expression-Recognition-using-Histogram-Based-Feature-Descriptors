load 'microexp_lpq_top_cropped.mat'

tic
template = templateSVM('Standardize', 1, 'KernelFunction', 'linear');

model = fitcecoc(features, labels, 'Learners', template, 'Leaveout', 'on', 'Coding', 'onevsall');

100 * (1 - kfoldLoss(model))
toc