function [ H ] = lbp_top_regions(  sequence, P, R, num2histbin, region_n, region_m, blocks_t )
    
    th = linspace(0, 2*pi, P+1) + pi + pi/4;
    th = th(1:end-1);
    fun = @(block_struct) single_region_lbp_top(block_struct, R, th, num2histbin);
    
    t_idx = linspace(1, size(sequence, 3), blocks_t+1);
    H = [];
    for i=2:length(t_idx)
        seq_block = sequence(:, :, round(t_idx(i-1)) : round(t_idx(i)));
        H_block = blockproc(seq_block, [region_n region_m], fun, 'PadPartialBlocks', true, 'TrimBorder', false);
    
        % stack all rows into one long vector
        H_block = reshape(H_block', 1, []);
        H = [H H_block];
    end
end

function [ H ] = single_region_lbp_top(block_struct, R, th, num2histbin)
    seq_block = block_struct.data;
    M = block_struct.blockSize(1);
    N = block_struct.blockSize(2);
    T = size(seq_block, 3);
    
    XY = seq_block(:, :, round(T/2.0));
    XT = seq_block(:, round(N/2.0), :);
    YT = seq_block(round(M/2.0), :, :);
    
    XT = squeeze(XT(:, 1, :));
    YT = squeeze(YT(1, :, :));
      
    Rx = R(1);
    Ry = R(1);
    Rt = R(1);
    
    H_xy = single_region_LBP(XY, M, N, Rx, th, num2histbin);
    H_xt = single_region_LBP(XT, M, T, Rt, th, num2histbin);
    H_yt = single_region_LBP(YT, N, T, Ry, th, num2histbin);
    
    H = [H_xy H_xt H_yt];
end

function [H_single] = single_region_LBP(img, M, N, R, thetas, num2histbin)
    % pad image with border of zeros
    img_block_filled = zeros(size(img) + 2*R);
    img_block_filled(R+1:end-R, R+1:end-R) = img;
    
    [X, Y] = meshgrid(1+R:M+R, 1+R:N+R);
    
    X_linear = X(:);
    Y_linear = Y(:);
    x_cos = repmat(R * cos(thetas), size(X_linear, 1), 1);
    y_sin = repmat(R * sin(thetas), size(Y_linear, 1), 1);
    xunit = bsxfun(@plus, x_cos, X_linear);
    yunit = bsxfun(@plus, y_sin, Y_linear);
    
    pixels=interp2(img_block_filled, xunit, yunit, 'linear');
    threshold_values = img(:);
    binary = bsxfun(@ge, pixels, threshold_values);
    
    decimal = bi2de(binary);
    
    % apply decimal number to bin mapping
    bins_mapped = num2histbin(decimal + 1);
    H_single = histcounts(bins_mapped, 0.5:length(unique(num2histbin))+1);

end